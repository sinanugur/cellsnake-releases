#!/bin/bash

workflow/scripts/scrna-install-packages.R
